<?php

namespace App\Controllers;
use App\Models\MahasiswaModel;

class Profil extends BaseController
{
    public function beranda()
    {
        $mahasiswa = new MahasiswaModel();
        return view('Profil',[
            "data" => $mahasiswa->getNama()
        ]);
    }
}
